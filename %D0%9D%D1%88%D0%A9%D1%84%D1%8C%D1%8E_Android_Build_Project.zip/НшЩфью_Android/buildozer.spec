[app]
title = НшЩфью
package.name = nshshfyu
package.domain = org.realstories
source.dir = .
source.include_exts = py,json,jpg,png,kv,txt
version = 1.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.permissions = INTERNET
android.accept_sdk_license = True
android.private_storage = True
p4a.bootstrap = sdl2

[buildozer]
log_level = 2
warn_on_root = 1
