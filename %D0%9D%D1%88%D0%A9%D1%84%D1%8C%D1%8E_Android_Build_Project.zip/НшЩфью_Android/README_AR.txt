НшЩфью — Android build project
================================

هذه الحزمة تحتوي على مشروع Kivy مهيأ للبناء كـ APK، لكنها ليست ملف APK جاهزًا.
لم يتم بناء APK داخل هذه البيئة.

الملفات:
- main.py: واجهة Kivy مناسبة لشاشة الهاتف
- stories.json: بيانات القصص وروابط المصادر
- favorites.json: تُحفظ فيه المفضلة
- 1000188548.jpg: الخلفية
- buildozer.spec: إعدادات بناء Android

بناء APK (الطريقة الموصى بها: Linux أو Ubuntu عبر WSL2):
1) ثبّت Python 3 و Java JDK 17 و Git و أدوات بناء Android المطلوبة لـ Buildozer.
2) افتح الطرفية داخل مجلد المشروع.
3) أنشئ بيئة افتراضية:
   python3 -m venv .venv
   source .venv/bin/activate
4) ثبّت Buildozer:
   pip install --upgrade pip setuptools
   pip install buildozer cython
5) ابنِ نسخة Debug:
   buildozer android debug
6) عند اكتمال البناء، ستجد ملف APK داخل مجلد bin/.
7) انقل APK إلى الهاتف، وافتحه لتثبيته. قد تحتاج إلى السماح بالتثبيت من هذا المصدر.

ملاحظات:
- أول بناء يحتاج إنترنت وقد يستغرق وقتًا لتنزيل Android SDK/NDK.
- بناء APK مباشرة على أندرويد/Pydroid غير موثوق؛ استخدم Linux/Ubuntu أو خدمة بناء Android.
- تأكد من مراجعة الروابط داخل stories.json؛ القصة داخل التطبيق ملخص عربي والرابط يقود إلى المصدر.
- اسم التطبيق الظاهر هو НшЩфью. معرّف الحزمة: org.realstories.nshshfyu.
