# -*- coding: utf-8 -*-
import json
import os
import webbrowser
from kivy.app import App
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.graphics import Color, Rectangle
from kivy.utils import platform

Window.clearcolor = (0.035, 0.075, 0.12, 1)

APP_TITLE = "НшЩфью"
HERE = os.path.dirname(os.path.abspath(__file__))
STORIES_FILE = os.path.join(HERE, "stories.json")
FAVORITES_FILE = os.path.join(HERE, "favorites.json")
BACKGROUND_FILE = os.path.join(HERE, "1000188548.jpg")

def load_json(path, fallback):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return fallback

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

class StoryApp(App):
    title = APP_TITLE

    def build(self):
        self.stories = load_json(STORIES_FILE, [])
        self.favorites = set(str(x) for x in load_json(FAVORITES_FILE, []))
        self.category = "الكل"
        self.page = "home"
        self.root_layout = FloatLayout()
        if os.path.exists(BACKGROUND_FILE):
            self.bg = Image(source=BACKGROUND_FILE, allow_stretch=True, keep_ratio=False,
                            opacity=0.28, size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
            self.root_layout.add_widget(self.bg)
        else:
            self.bg = None
        self.panel = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(8),
                               size_hint=(1, 1), pos_hint={"x": 0, "y": 0})
        with self.panel.canvas.before:
            Color(0.025, 0.055, 0.09, 0.91)
            self.panel_bg = Rectangle(pos=self.panel.pos, size=self.panel.size)
        self.panel.bind(pos=self._update_panel_bg, size=self._update_panel_bg)
        self.root_layout.add_widget(self.panel)
        self.show_home()
        return self.root_layout

    def _update_panel_bg(self, *_):
        self.panel_bg.pos = self.panel.pos
        self.panel_bg.size = self.panel.size

    def label(self, text, size=16, color=(1,1,1,1), height=None, bold=False):
        return Label(text=text, font_size=dp(size), color=color,
                     size_hint_y=None if height else 1,
                     height=dp(height) if height else 0,
                     text_size=(Window.width - dp(36), None),
                     halign="right", valign="middle",
                     bold=bold)

    def button(self, text, callback, height=46):
        b = Button(text=text, size_hint_y=None, height=dp(height),
                   background_normal="", background_down="",
                   background_color=(0.08, 0.30, 0.48, 1),
                   color=(1,1,1,1), font_size=dp(16))
        b.bind(on_release=lambda *_: callback())
        return b

    def clear(self):
        self.panel.clear_widgets()

    def add_header(self):
        header = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(6))
        header.add_widget(self.button("الرئيسية", self.show_home, 44))
        header.add_widget(self.label("НшЩфью", 23, (0.55,0.80,1,1), 44, True))
        self.panel.add_widget(header)

    def show_home(self, *_):
        self.page = "home"
        self.clear()
        self.add_header()
        self.panel.add_widget(Label(text="وراء كل حقيقة قصة", font_size=dp(28),
                                    bold=True, color=(1,1,1,1), size_hint_y=None,
                                    height=dp(90), halign="center"))
        self.panel.add_widget(Label(
            text="اكتشف قصصًا تاريخية وإنسانية موثقة، واقرأ تفاصيلها وافتح مصادرها الأصلية.",
            font_size=dp(17), color=(0.82,0.89,0.96,1),
            size_hint_y=None, height=dp(100), halign="center",
            text_size=(Window.width-dp(40), None)))
        self.panel.add_widget(self.button("استكشف القصص", self.show_explore, 54))
        self.panel.add_widget(self.button("قصصي المفضلة", self.show_favorites, 54))
        self.panel.add_widget(Label(text=f"عدد القصص: {len(self.stories)}",
                                    font_size=dp(15), color=(0.55,0.80,1,1)))
        if not os.path.exists(BACKGROUND_FILE):
            self.panel.add_widget(Label(text="صورة الخلفية غير موجودة داخل المشروع.",
                                        color=(1,0.75,0.35,1), font_size=dp(13)))

    def show_explore(self, *_):
        self.page = "explore"
        self.category = "الكل"
        self.render_list(False)

    def show_favorites(self, *_):
        self.page = "favorites"
        self.category = "الكل"
        self.render_list(True)

    def render_list(self, only_favorites=False):
        self.clear()
        self.add_header()
        self.panel.add_widget(Label(text="المفضلة" if only_favorites else "استكشف القصص",
                                    size_hint_y=None, height=dp(42), font_size=dp(22),
                                    bold=True, color=(1,1,1,1)))
        self.search = TextInput(hint_text="ابحث عن قصة...", multiline=False,
                                size_hint_y=None, height=dp(46), font_size=dp(16),
                                halign="right", background_color=(0.10,0.16,0.22,1),
                                foreground_color=(1,1,1,1), cursor_color=(0.5,0.8,1,1))
        self.search.bind(text=lambda *_: self.refresh_cards(only_favorites))
        self.panel.add_widget(self.search)
        cats = ["الكل"] + sorted(set(s.get("category", "عام") for s in self.stories))
        catrow = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        # A compact category picker suitable for phones.
        self.cat_button = self.button("التصنيف: الكل", lambda: self.cycle_category(cats, only_favorites), 42)
        catrow.add_widget(self.cat_button)
        catrow.add_widget(self.button("تحديث", lambda: self.refresh_cards(only_favorites), 42))
        self.panel.add_widget(catrow)
        self.scroll = ScrollView()
        self.cards = BoxLayout(orientation="vertical", spacing=dp(8), size_hint_y=None,
                               padding=(0, dp(4), 0, dp(12)))
        self.cards.bind(minimum_height=self.cards.setter("height"))
        self.scroll.add_widget(self.cards)
        self.panel.add_widget(self.scroll)
        self.refresh_cards(only_favorites)

    def cycle_category(self, categories, only_favorites):
        try:
            i = categories.index(self.category)
        except ValueError:
            i = 0
        self.category = categories[(i + 1) % len(categories)]
        self.cat_button.text = "التصنيف: " + self.category
        self.refresh_cards(only_favorites)

    def refresh_cards(self, only_favorites=False):
        if not hasattr(self, "cards"):
            return
        self.cards.clear_widgets()
        query = self.search.text.strip().casefold() if hasattr(self, "search") else ""
        items = self.stories
        if only_favorites:
            items = [s for s in items if str(s.get("id")) in self.favorites]
        if self.category != "الكل":
            items = [s for s in items if s.get("category") == self.category]
        if query:
            items = [s for s in items if query in (
                s.get("title","") + " " + s.get("summary","") + " " + s.get("category","")
            ).casefold()]
        if not items:
            self.cards.add_widget(Label(text="لا توجد قصص مطابقة.", size_hint_y=None,
                                        height=dp(60), font_size=dp(16)))
            return
        for story in items:
            card = BoxLayout(orientation="vertical", size_hint_y=None,
                             height=dp(190), padding=dp(10), spacing=dp(4))
            with card.canvas.before:
                Color(0.07, 0.13, 0.19, 0.96)
                rect = Rectangle(pos=card.pos, size=card.size)
            card.bind(pos=lambda obj, val, r=rect: setattr(r, "pos", val),
                      size=lambda obj, val, r=rect: setattr(r, "size", val))
            card.add_widget(Label(text=story.get("title",""), font_size=dp(17),
                                  bold=True, color=(0.62,0.83,1,1),
                                  size_hint_y=None, height=dp(40),
                                  halign="right", text_size=(Window.width-dp(60), None)))
            card.add_widget(Label(text=f'{story.get("category","")} • {story.get("date","")}',
                                  font_size=dp(12), color=(0.75,0.82,0.9,1),
                                  size_hint_y=None, height=dp(22), halign="right"))
            card.add_widget(Label(text=story.get("summary",""), font_size=dp(13),
                                  color=(0.93,0.95,0.98,1), size_hint_y=None,
                                  height=dp(52), halign="right",
                                  text_size=(Window.width-dp(60), None)))
            row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
            row.add_widget(self.button("اقرأ القصة", lambda s=story: self.show_story(s), 38))
            is_fav = str(story.get("id")) in self.favorites
            row.add_widget(self.button("★ إزالة" if is_fav else "☆ المفضلة",
                                       lambda s=story, fav=only_favorites: self.toggle_fav(s, fav), 38))
            card.add_widget(row)
            self.cards.add_widget(card)

    def toggle_fav(self, story, only_favorites=False):
        sid = str(story.get("id"))
        if sid in self.favorites:
            self.favorites.remove(sid)
        else:
            self.favorites.add(sid)
        save_json(FAVORITES_FILE, sorted(self.favorites))
        self.refresh_cards(only_favorites)

    def show_story(self, story):
        previous = self.page
        self.page = "detail"
        self.clear()
        self.add_header()
        self.panel.add_widget(self.button("رجوع إلى القصص", self.show_favorites if previous == "favorites" else self.show_explore, 42))
        self.panel.add_widget(Label(text=story.get("title",""), font_size=dp(23),
                                    bold=True, color=(0.65,0.84,1,1),
                                    size_hint_y=None, height=dp(80),
                                    halign="right", text_size=(Window.width-dp(40), None)))
        self.panel.add_widget(Label(text=f'{story.get("category","")} • {story.get("date","")}',
                                    font_size=dp(13), color=(0.8,0.88,0.95,1),
                                    size_hint_y=None, height=dp(32), halign="right"))
        body = ScrollView()
        text = Label(text=story.get("summary","") + "\\n\\n" + story.get("details",""),
                     font_size=dp(17), color=(1,1,1,1), size_hint_y=None,
                     halign="right", valign="top", text_size=(Window.width-dp(48), None))
        text.bind(texture_size=lambda obj, size: setattr(obj, "height", size[1] + dp(30)))
        body.add_widget(text)
        self.panel.add_widget(body)
        self.panel.add_widget(self.button("افتح المصدر الأصلي", lambda: self.open_source(story), 48))
        sid = str(story.get("id"))
        self.panel.add_widget(self.button("إزالة من المفضلة" if sid in self.favorites else "أضف للمفضلة",
                                          lambda: self.toggle_from_detail(story, previous), 44))

    def toggle_from_detail(self, story, previous):
        sid = str(story.get("id"))
        if sid in self.favorites:
            self.favorites.remove(sid)
        else:
            self.favorites.add(sid)
        save_json(FAVORITES_FILE, sorted(self.favorites))
        self.show_story(story)

    def open_source(self, story):
        url = story.get("source", "")
        if url.startswith("https://") or url.startswith("http://"):
            try:
                webbrowser.open(url)
            except Exception:
                popup = Popup(title="رابط المصدر", content=Label(text=url),
                              size_hint=(0.9, 0.35))
                popup.open()

if __name__ == "__main__":
    StoryApp().run()
